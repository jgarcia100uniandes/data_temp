@XmlAccessorType(XmlAccessType.FIELD)
@XmlJavaTypeAdapter(value = DateAdapter.class, type = Date.class)
package co.edu.uniandes.csw.homeservices.dtos;

import co.edu.uniandes.csw.auth.model.DateAdapter;
import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
