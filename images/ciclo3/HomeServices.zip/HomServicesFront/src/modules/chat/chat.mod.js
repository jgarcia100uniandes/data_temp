(function (ng) {
    var mod = ng.module('chatModule', ['ngCrud']);

    mod.constant('chatContext', 'chats');



})(window.angular);
